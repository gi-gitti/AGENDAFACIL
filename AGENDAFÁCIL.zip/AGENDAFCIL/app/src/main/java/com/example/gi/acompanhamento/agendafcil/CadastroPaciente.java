package com.example.gi.acompanhamento.agendafcil;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CadastroPaciente extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_paciente);
    }
}
